set -euxa

FC=xlf_r   AC=xlc  BUFRLIB=bufrlib.a  CPP=/usr/lib/cpp

preproc.sh

$FC -c *.f

$AC -c *.c

ar crv $BUFRLIB *.o
